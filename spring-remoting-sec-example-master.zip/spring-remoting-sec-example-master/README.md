spring-remoting-sec-example
===========================

Spring Security with Remoting.
[How to](http://seenukarthi.com/security/2013/01/19/spring-rmi-with-remote-userdetailsmanager/)
